function getComplaints() {
	
}

function init() {
	getComplaints();
	getFeedback();
}

init();