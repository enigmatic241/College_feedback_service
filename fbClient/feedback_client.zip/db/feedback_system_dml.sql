USE feedbacksystem

INSERT INTO category (id, categoryname) VALUES 
("001", "Hostel"),
("001", "Mess"),
("001", "Sports (Indoor)"),
("001", "Sports (Outdoor)");

INSERT INTO subcategory (id, categoryname, subcategoryname) VALUES 
("0001", "Hostel", "Light"),
("0002", "Hostel", "Bathroom"),
("0003", "Hostel", "Night Light"),
("0004", "Hostel", "Fan"),
("0005", "Hostel", "Bed"),
("0006", "Hostel", "Cleaning"),
("0007", "Hostel", "Lift"),
("0008", "Mess", "Food"),
("0009", "Mess", "Workers"),
("0010", "Mess", "Chairs"),
("0011", "Mess", "Tables"),
("0012", "Mess", "TV");
