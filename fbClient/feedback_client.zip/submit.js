import axios from 'axios';
import "core-js/stable";
import "regenerator-runtime/runtime";

const getDBData = async (options) => {
	// console.log(options);
	if (options.reqType == "getCat") {
		axios.get('http://127.0.0.1:8080', {
			params: {
				reqType: "getCat"
			}
			})
			.then(function (response) {
				addOptions(response.data, "category");
			})
			.catch((err) => {
				throw new Error(err);
			});
	}
	else if (options.reqType == "submitComplaint") {
		var categorySelected = document.getElementById("slctCat").value;
		var subcategorySelected = document.getElementById("slctSubcat").value;
		var txtHostel = document.getElementById("txtHostel");
		var txtFloor = document.getElementById("txtFloor");
		var txtRoom = document.getElementById("txtRoom");
		var txtDiscrip = document.getElementById("txtDiscrip");
		var description = "";
		if (txtHostel.value != "") description += "Hostel: " + txtHostel.value;
		if (txtFloor.value != "") description += " Floor: " + txtFloor.value;
		if (txtRoom.value != "") description += " Room: " + txtRoom.value;
		if (txtDiscrip.value != "") description += " " + txtDiscrip.value;
		console.log(description);
		axios.get('http://127.0.0.1:8080', {
			params: {
				reqType: "submitcomplaint",
				category: categorySelected,
				subcategory: subcategorySelected,
				description: description
			}
			})
			.then(function (response) {
				
			})
			.catch((err) => {
				throw new Error(err);
			});
	}
	else if (options.target.reqType == "getSubcat") {
		var categorySelected = document.getElementById("slctCat").value;
		axios.get('http://127.0.0.1:8080', {
			params: {
				reqType: "getSubcat",
				categoryName: categorySelected
			}
			})
			.then(function (response) {
				addOptions(response.data, "subcategory");
			})
			.catch((err) => {
				throw new Error(err);
			});
	}
	// console.log(options.target.value);
};

const createOption = item => {
	const option = document.createElement('option');
	option.value = item;
	option.appendChild(document.createTextNode(item));
	return option;
};

const addOptions = (categoryList, selectType) => {
	// console.log(categoryList);
	if (selectType == "category") {
		const slctCat = document.getElementById("slctCat");
		// document.getElementById('slctCat').innerHTML = '';

		if (Array.isArray(categoryList) && categoryList.length > 0) {
			categoryList.map(category => {
				slctCat.appendChild(createOption(category.categoryname));
			});
			slctCat.appendChild(createOption("Other"));
		} else if (categoryList) {
			slctCat.appendChild(createOption(categoryList.categoryname));
		}
	}
	else if (selectType == "subcategory") {
		const slctSubcat = document.getElementById("slctSubcat");
		document.getElementById('slctSubcat').innerHTML = '';

		if (Array.isArray(categoryList) && categoryList.length > 0) {
			categoryList.map(category => {
				slctSubcat.appendChild(createOption(category.subcategoryname));
			});
			slctSubcat.appendChild(createOption("Other"));
		} else if (categoryList) {
			slctSubcat.appendChild(createOption(categoryList.subcategoryname));
		}
	}
};

const validateData = () => {
	getDBData({reqType: "submitComplaint"});
}

const init = async () => {
	document.getElementById("slctCat").reqType = "getSubcat";
	document.getElementById("slctCat").addEventListener("change", getDBData);
	document.getElementById("btnSubmit").addEventListener("click", validateData);
	await getDBData({reqType: "getCat"});
};

init();