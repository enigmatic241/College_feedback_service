// var url = require('url');
// const request = require('request');
// var url_parts = url.parse(request.url, true);
var mysql = require('mysql');
const express = require('express');
const app = express();
const port = 8080;
var con = mysql.createConnection({
    host: "0.0.0.0",
    // host: "localhost",
    user: "root",
    password: "root",
    database: "feedbacksystem"
});

con.connect(function(err) {
    app.get('/', (req, res) => {
        // console.log(req);
        if (req.query.reqType == "getCat") {
            if (err) throw err;
            var sql = "SELECT categoryname FROM category";
            con.query(sql, function (err, result) {
                if (err) throw err;
                console.log(result);
                res.header("Access-Control-Allow-Origin", "*");
                res.send(result);
            });
        }
        else if (req.query.reqType == "submitcomplaint") {
            if (err) throw err;
            var sql = "INSERT INTO complaint (categoryname, subcategoryname, description) VALUES ('";
            sql += req.query.category + "', '" + req.query.subcategory + "', '" + req.query.description + "')";
            console.log(sql);
            con.query(sql, function (err, result) {
                if (err) throw err;
                console.log(result);
                res.header("Access-Control-Allow-Origin", "*");
                // res.send(result);
            });
        }
        else if (req.query.reqType == "getSubcat") {
            if (err) throw err;
            var sql = "SELECT subcategoryname FROM subcategory where categoryname='" + req.query.categoryName + "'";
            con.query(sql, function (err, result) {
                if (err) throw err;
                console.log(result);
                res.header("Access-Control-Allow-Origin", "*");
                res.send(result);
            });
        }
        // res.send('Hello World!');
    })
});

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
})

// var con = mysql.createConnection({
// 	host: "root",
// 	user: "root",
// 	password: "root",
// 	database: "feedback_system"
// });

// if (reqType == 'getCat') {
// 	con.connect(function(err) {
// 		if (err) throw err;
// 		var sql = "SELECT categoryname FROM category";
// 		con.query(sql, function (err, result) {
// 			if (err) throw err;
// 			// console.log(result.categoryname);
// 			// console.log(result.affectedRows + " record(s) updated");
// 			return result;
// 		});
// 	});
// }
